<!DOCTYPE html>
<html lang="ru">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Страница моего резюме</title>
  <link rel="shortcut icon" href="/images/favicon.png">
  <link rel="stylesheet" type="text/css" href="/css/style.css">
  <script type="text/javascript" src="/js/TaskLesson.js" defer></script>
</head>

<body>
  <script>


  </script>
  <div class="header">
    <img class="logo" src="/images/logo.png" alt="Logo">
    <h1>Добро пожаловать на мою страницу!</h1>
    <div class="menu">
      <ul>
        <li><a href="/">Обо мне</a></li>
        <li><a href="#bla-bla">Мой опыт</a></li>
        <li><a href="#foot">Мои контакты</a></li>
      </ul>
    </div>
  </div>
  <div class="container">
    <img class="photo" src="/images/logo.png" alt="мое фото">
    <div class="content">
      <h2>Обо мне:</h2>
      <p>Всем привет. Вы на странице моего резюме. Давайте знакомиться.</p>
      <p>Меня зовут Виталий, я - фриланс backend-разработчик сайтов на WordPress, <br /> а также в компании Seraphinite Solutions</p>
      <p>В свободное от основной работы время я преподаю основы IT в компании GeekBrains и GeekSchool, играю на гитаре любимые песни <br />малоизвестных и слегка подзабытых рок-групп</p>
      <p>Увлекаюсь также просмотром стримов по дисциплине CS:GO</p>
      <p>Одно время увлекался игрой в настольный теннис</p>
      <p>Буду рад услышать ваши истории!</p>

      <h2 id="bla-bla">Мои достижения:</h2>
      <p>Участвовал в конференциях WordCamp Russia, пока это не стало мейнстримом</li>
      </p>
      <p>Со-основатель локального сообщества WordPress в своем городе, являющегося частью глобального WordPress Community</p>
      <p>Обучаю основам IT с 2017 года</p>
      <p>Собираюсь однажды побывать на Шпицбергене</p>

      
    </div>
  </div>
  <div class="footer" id="foot">
    <p class="copyright">Все права защищены. Для того, чтобы перейти вверх, нажмите на ссылку ниже</a></p>
    <a class="top" href="#top">Перейти вверх страницы</a>
  </div>
</body>

</html>