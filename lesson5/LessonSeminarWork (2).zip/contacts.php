<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Страница моего резюме</title>
  <link rel="shortcut icon" href="/images/favicon.png">
  <link rel="stylesheet" type="text/css" href="/css/style.css">
</head>
<body>
<div class="header">
    <img class="logo" src="/images/logo.png" alt="Logo">
    <h1>Добро пожаловать на мою страницу!</h1>
    <div class="menu">
      <ul>
        <li><a href="index.html">Обо мне</a></li>
        <li><a href="achivments.html">Мой опыт</a></li>
        <li><a href="contacts.html">Мои контакты</a></li>
      </ul>
    </div>
  </div>
<div class="container">
  <img class="photo" src="/images/logo.png" alt="мое фото">
  <div class="content">
    <h2>Мои контакты:</h2>
    <p>Село Кудыкино, площадь восстания, 2</p>
    <p>Email:kudi_ty_idesh@mail.ru</p>
    <p>Tel:+79104908870</p>    

  </div>
  </div>
  <div class="footer">
    <p class="copyright">Все права защищены. Для того, чтобы перейти вверх, нажмите на ссылку ниже</a></p>
    <a class="top" href="#top">Перейти вверх страницы</a>
  </div>
</body>
</html>