let userName = prompt("Как Вас зовут?", "Имя");
function showMessage() {
  let message = `Привет, ${userName}`; 
  alert(message);
}
showMessage();
